﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using VectorTest.API.Models;

namespace VectorTest.API.Repository
{
    //acessa api moc para recuperar email caso nao exista na base do mongo
    public class RepositorioGetApi : IRepositorioGetApi
    {
        HttpClient clientApi = new HttpClient();
        public RepositorioGetApi()
        {
            clientApi.BaseAddress = new Uri("https://6064ac2bf09197001778660d.mockapi.io/");
            clientApi.DefaultRequestHeaders.Accept.Add(
           new MediaTypeWithQualityHeaderValue("appication/json"));
        }

        public async Task<Email> GetUsuarioIdAsync(int id)
        {
            HttpResponseMessage reponse = await clientApi.GetAsync("api/test-api/" + id);
            if (reponse.IsSuccessStatusCode)
            {
                var dados = await reponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Email>(dados);
            }

            return new Email();

        }

        public async Task<Email> GetUsuarioEmail(string email)
        {
            HttpResponseMessage reponse = await clientApi.GetAsync("api/test-api/?mail=" + email);
            if (reponse.IsSuccessStatusCode)
            {
                var dados = await reponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<Email>(dados);
            }

            return new Email();

        }

        public async Task<IEnumerable<Email>> GetUsuarioAllAsync()
        {
            HttpResponseMessage reponse = await clientApi.GetAsync("api/test-api/");
            if (reponse.IsSuccessStatusCode)
            {
                var dados = await reponse.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<IEnumerable<Email>>(dados);
            }

            return default;

        }

  
    }
}
