﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VectorTest.API.Models;

namespace VectorTest.API.Repository
{
    public interface IRepositorioGetApi
    {

        Task<IEnumerable<Email>> GetUsuarioAllAsync();
        Task<Email> GetUsuarioIdAsync(int id);

        Task<Email> GetUsuarioEmail(string email);
    }
}
