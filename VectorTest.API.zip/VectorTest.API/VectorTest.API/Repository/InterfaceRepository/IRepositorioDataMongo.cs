﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VectorTest.API.Models;

namespace VectorTest.API.Repository
{
    public interface IRepositorioDataMongo
    {
        Task<IEnumerable<Email>> GetAll();
        Task<IEnumerable<Email>> CreateAll(IEnumerable<Email> email);
        Task<Email> CreateOne(Email email);
        Task<Email> GetById(int id);
        Task<Users> CreateUsers(Users users);
        Users GetByUser(string user, string senha);

       



    }
}
