﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VectorTest.API.Models;

namespace VectorTest.API.Repository
{
    public class RepositorioDataMongo : IRepositorioDataMongo
    {
        private readonly IMongoCollection<Email> _emails;
        private readonly IMongoCollection<Users> _users;

        //configura conexão com mongodb
        public RepositorioDataMongo(IDatabaseSettings settings)
        {
            //recupera paramegtros da config
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _emails = database.GetCollection<Email>(settings.EmailsCollectionName);
            _users = database.GetCollection<Users>(settings.UsersCollectionName);
        }


        //recurepa todos emails
        public async Task<IEnumerable<Email>> GetAll()
        {

            return (await _emails.FindAsync(email => true)).ToEnumerable();

        }

        //recupera email por id
        public async Task<Email> GetById(int id)
        {
            return (await _emails.FindAsync<Email>(email => email.Id == id)).FirstOrDefault();
        }


     
        //cria lista de email no mongo
        public async Task<IEnumerable<Email>> CreateAll(IEnumerable<Email> email)
        {
            await _emails.InsertManyAsync(email);

            return email;

        }

        //insere somente um email 
        public async Task<Email> CreateOne(Email email)
        {
            await _emails.InsertOneAsync(email);

            return email;

        }

  
        //crua usuarios no banco
        public async Task<Users> CreateUsers(Users users)
        {
            await _users.InsertOneAsync(users);

            return users;

        }

        //recupera usuario
        public Users GetByUser(string user, string senha)
        {
            return  _users.Find<Users>(u => u.Username == user &&  u.Password == senha).FirstOrDefault();
        }



    }
}
