﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VectorTest.API.Models;

namespace VectorTest.API.Services.InterfaceServices
{
    public interface IUserService
    {

        Task<Users> CreateUser(Users user);
        Users GetUser(string user, string senha);
    }
}
