﻿using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using VectorTest.API.Models;
using VectorTest.API.Repository;
using VectorTest.API.Services.InterfaceServices;

namespace VectorTest.API.Services
{
    //camada de serviços 
    public class EmailsService : IEmailService 
    {
        private readonly IRepositorioDataMongo _repostorioDataMongo;
        private IRepositorioGetApi _repostorioGetApi;

        public EmailsService(IRepositorioDataMongo repositorioDataMongo, IRepositorioGetApi repositorioGetApi)
        {
            _repostorioDataMongo = repositorioDataMongo;
            _repostorioGetApi = repositorioGetApi;

        }

        public async Task<IEnumerable<Email>> GetAll()
        {
           var getAll = (await _repostorioDataMongo.GetAll()).ToList();

            if (!getAll.Any())
            {
                getAll = (await _repostorioGetApi.GetUsuarioAllAsync()).ToList();

                await _repostorioDataMongo.CreateAll(getAll);

            }

            return  getAll;
        }

        public async Task<Email> GetId(int id)
        {

            var getId = await _repostorioDataMongo.GetById(id);

            if (getId == null)
            {
                getId = await _repostorioGetApi.GetUsuarioIdAsync(id);

                await _repostorioDataMongo.CreateOne(getId);

            }

            return getId;
        }

   


    }
}
