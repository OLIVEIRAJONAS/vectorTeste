﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VectorTest.API.Models;
using VectorTest.API.Repository;
using VectorTest.API.Services.InterfaceServices;

namespace VectorTest.API.Services
{
    //camada de serviço para recuperar user 
    public class UserService : IUserService
    {
        private readonly IRepositorioDataMongo _repostorioDataMongo;
        public UserService(IRepositorioDataMongo repositorioDataMongo)
        {
            _repostorioDataMongo = repositorioDataMongo;

        }


        public async Task<Users> CreateUser(Users user)
        {
                                 
            user.Issuer = "emissor";
            user.Audience = "receptor";
            user.key = Guid.NewGuid();
  

            var retornoUser = await _repostorioDataMongo.CreateUsers(user);

            return retornoUser;
        }


        public Users GetUser(string user, string senha)
        {

            Users getUser = _repostorioDataMongo.GetByUser(user,  senha);


            return getUser;
        }


       
    }
}
