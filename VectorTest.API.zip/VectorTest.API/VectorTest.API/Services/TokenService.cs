﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using VectorTest.API.Models;
using VectorTest.API.Services.InterfaceServices;

namespace VectorTest.API.Services
{
    //camada de serviço para gerar token
    public  class TokenService : ITokenService
    {
        private readonly IConfiguration _config;
        private IUserService _userService;

        public TokenService(IConfiguration Configuration, IUserService userService)
        {
            _config = Configuration;
            _userService = userService;
        }

        public string GenerateToken(string user , string senha)
        {
          var usuariologar = _userService.GetUser( user, senha);



            if (usuariologar != null)
            {

                var _secretKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
                var _issuer = _config["Jwt:Issuer"];
                var _audience = _config["Jwt:Audience"];
                var signinCredentials = new SigningCredentials(_secretKey, SecurityAlgorithms.HmacSha256);
                var tokeOptions = new JwtSecurityToken(
                    issuer: _issuer,
                    audience: _audience,
                    claims: new List<Claim>(),
                    expires: DateTime.Now.AddMinutes(2),
                    signingCredentials: signinCredentials);
                var tokenString = new JwtSecurityTokenHandler().WriteToken(tokeOptions);

                return tokenString;
            }
            return null;
        }
    }
}
